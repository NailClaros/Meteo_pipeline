from __future__ import annotations

__version__ = "1.2.2"
VERSION = __version__.split(".")
