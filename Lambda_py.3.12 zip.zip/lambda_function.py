import os
from weathercalls import fetch_and_save_weather_data
from db import upload_weather_data_to_db
from awsfuncs import file_exists_in_s3, s3, upload_file
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

BUCKET_NAME = os.getenv("BUCKET_NAME")
DB_URL = os.getenv("DB_URL")


def lambda_handler(event, context):
    try:
        # Determine date to process (UTC)
        today_str = datetime.now().strftime("%Y-%m-%d")
        filename = f"weather_{today_str}.csv"
        local_path = f"/tmp/{filename}"  # Lambda writable temp path
        s3_key = filename

        bucket = os.environ["BUCKET_NAME"]
        db_url = os.environ["DB_URL"]

        # 1. Fetch if not already fetched locally
        if not os.path.exists(local_path):
            # Assume fetch_and_save_weather_data can accept output_path override
            fetch_and_save_weather_data(date=datetime.now())

        # 2. Upload to S3 if not present
        if not file_exists_in_s3(bucket, s3_key):
            upload_file(bucket, local_path, s3_key)
        print("ATTEMPTING UPLOAD")
        # 3. Insert to DB (internal logic should dedupe based on filename)
        upload_weather_data_to_db(bucket_name=bucket, db_url=db_url)

        return {
        "statusCode": 200,
        "body": "Pipeline executed successfully."
        }
    except Exception as e:
        # Let Lambda log stack trace automatically; also return error
        print("Pipeline error:", e)
        raise  # so Lambda marks as failure